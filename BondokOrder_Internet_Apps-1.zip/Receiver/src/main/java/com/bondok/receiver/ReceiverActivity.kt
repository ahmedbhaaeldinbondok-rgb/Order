package com.bondok.receiver
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
class ReceiverActivity:AppCompatActivity(){
 private val DB="https://YOUR-PROJECT-default-rtdb.firebaseio.com"; private lateinit var list:LinearLayout; private var run=true
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_receiver);list=findViewById(R.id.list);poll()}
 private fun poll(){thread{while(run){try{val c=URL("$DB/requests.json").openConnection() as HttpURLConnection;c.requestMethod="GET"
 val s=c.inputStream.bufferedReader().readText();val root=if(s=="null")JSONObject() else JSONObject(s);runOnUiThread{render(root)}
 }catch(_:Exception){};Thread.sleep(2000)}}}
 private fun render(root:JSONObject){list.removeAllViews();val keys=root.keys().asSequence().toList().sortedDescending()
 if(keys.isEmpty()){TextView(this).also{it.text="لا توجد طلبات جديدة";it.textSize=20f;list.addView(it)};return}
 for(k in keys){val o=root.optJSONObject(k)?:continue;val card=LinearLayout(this);card.orientation=LinearLayout.VERTICAL;card.setPadding(16,16,16,16)
 val t=TextView(this);t.text="👤 ${o.optString("requesterName")} • شقة ${o.optString("requesterApartment")}";t.textSize=19f
 val x=TextView(this);x.text="📨 إلى: ${o.optString("receiverName")}\n🛒 ${o.optString("item")}\nالحالة: ${o.optString("status")}";x.textSize=17f
 card.addView(t);card.addView(x)
 if(o.optString("status")!="DONE"){Button(this).also{it.text="قبول";it.setOnClickListener{update(k,"ACCEPTED")};card.addView(it)}
 Button(this).also{it.text="تم التنفيذ";it.setOnClickListener{update(k,"DONE")};card.addView(it)}
 list.addView(card)}}}
 private fun update(id:String,status:String){thread{try{val c=URL("$DB/requests/$id/status.json").openConnection() as HttpURLConnection;c.requestMethod="PUT";c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(JSONObject.quote(status).toByteArray())}}catch(_:Exception){}}}
 override fun onDestroy(){run=false;super.onDestroy()}
}