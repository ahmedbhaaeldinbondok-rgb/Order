# BONDOK ORDER — Internet version
Bluetooth removed. Two Android apps communicate through Firebase Realtime Database.
Requester records: requesterName, apartment, receiverName, item, createdAt, status.
Receiver polls the database and can mark ACCEPTED or DONE.

SETUP:
1) Create a Firebase project and Realtime Database.
2) Replace YOUR-PROJECT-default-rtdb.firebaseio.com in BOTH Kotlin files with your database URL.
3) For a quick private home test only, temporary rules can be:
{
  "rules": { ".read": true, ".write": true }
}
Do not use open rules for a real public deployment; add Firebase Authentication and proper rules first.
