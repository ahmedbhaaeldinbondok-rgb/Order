package com.bondok.requester
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
class RequesterActivity: AppCompatActivity() {
    private val DB="https://YOUR-PROJECT-default-rtdb.firebaseio.com"
    override fun onCreate(b:Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_requester)
        val name=findViewById<EditText>(R.id.name); val apt=findViewById<EditText>(R.id.apartment)
        val to=findViewById<EditText>(R.id.receiver); val item=findViewById<EditText>(R.id.item)
        val send=findViewById<Button>(R.id.send); val status=findViewById<TextView>(R.id.status)
        send.setOnClickListener {
            if(name.text.isBlank()||to.text.isBlank()||item.text.isBlank()){status.text="اكتب البيانات المطلوبة";return@setOnClickListener}
            send.isEnabled=false; status.text="جاري الإرسال..."
            thread {
                try {
                    val id="req_"+System.currentTimeMillis()
                    val o=JSONObject().apply{
                        put("id",id);put("requesterName",name.text.toString());put("requesterApartment",apt.text.toString())
                        put("receiverName",to.text.toString());put("item",item.text.toString())
                        put("createdAt",System.currentTimeMillis());put("status","NEW")
                    }
                    val c=URL("$DB/requests/$id.json").openConnection() as HttpURLConnection
                    c.requestMethod="PUT";c.doOutput=true;c.setRequestProperty("Content-Type","application/json")
                    c.outputStream.use{it.write(o.toString().toByteArray())}; val ok=c.responseCode in 200..299
                    runOnUiThread{send.isEnabled=true;status.text=if(ok)"✅ الطلب وصل لقاعدة البيانات" else "❌ فشل الإرسال"}
                }catch(e:Exception){runOnUiThread{send.isEnabled=true;status.text="❌ تأكد من الإنترنت ورابط Firebase"}}
            }
        }
    }
}